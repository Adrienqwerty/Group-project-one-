class Item: 
  # Variable
  item = 0
  # Constructor
  def __init__(self, name, description):
      pass
  # Methods
  def add_item(self, user_input):
      if user_input == 't':
          self.item += 1